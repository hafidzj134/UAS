package com.example.Menu_Makanan.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.Menu_Makanan.Adapter.FoodAdapter;
import com.example.Menu_Makanan.Model.Food;
import com.example.Menu_Makanan.Model.GetFood;
import com.example.Menu_Makanan.R;
import com.example.Menu_Makanan.Rest.ApiClient;
import com.example.Menu_Makanan.Rest.ApiInterface;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    ApiInterface mApiInterface;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    public static MainActivity ma;
    private FloatingActionButton fabAdd;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecyclerView = (RecyclerView) findViewById(R.id.rv_food);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        ma=this;
        refresh();

        fabAdd = findViewById(R.id.fab_add);
        button = findViewById(R.id.btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this , activity_login.class);
                startActivity(intent);
            }
        });
        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, InsertActivity.class));
            }
        });
    }

    public void refresh() {
        Call<GetFood> FoodCall = mApiInterface.getFood();
        FoodCall.enqueue(new Callback<GetFood>() {
            @Override
            public void onResponse(Call<GetFood> call, Response<GetFood>
                    response) {
                List<Food> FoodList = response.body().getListDataFood();
                Log.d("Retrofit Get", "Jumlah data Food: " +
                        String.valueOf(FoodList.size()));
                mAdapter = new FoodAdapter(FoodList);
                mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<GetFood> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }
        });
    }

}